from adafruit_launchgrid import adafruit_launchgrid

def create_instance(c_instance):
	return adafruit_launchgrid(c_instance)
